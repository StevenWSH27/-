package com.job.mapper;

import com.job.bean.TUser;
import tk.mybatis.mapper.common.Mapper;

/**
 * 用户管理接口
 */
public interface TUserMapper extends Mapper<TUser> {

}
