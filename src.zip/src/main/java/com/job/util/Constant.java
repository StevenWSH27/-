package com.job.util;

public class Constant {
    public static String globaPath;
    public static final String SUCCESS_RETUEN_CODE = "0";
    public static final String FAILURE_RETUEN_CODE = "-9999";
}
